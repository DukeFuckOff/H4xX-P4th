package com.h4xxp4th.calls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** The chip mascot, drawn on a 100x100 grid. Last two numbers of each trace are the ring node. */
class MascotView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val traces = listOf(
        floatArrayOf(36f, 30f, 36f, 22f, 24f, 22f, 24f, 12f, 24f, 9f),
        floatArrayOf(43f, 30f, 43f, 16f, 34f, 16f, 34f, 8f, 34f, 5f),
        floatArrayOf(50f, 30f, 50f, 12f, 50f, 9f),
        floatArrayOf(57f, 30f, 57f, 18f, 66f, 18f, 66f, 9f, 66f, 6f),
        floatArrayOf(64f, 30f, 64f, 24f, 76f, 24f, 76f, 14f, 76f, 11f),
        floatArrayOf(70f, 36f, 80f, 36f, 80f, 30f, 90f, 30f, 93f, 30f),
        floatArrayOf(70f, 43f, 86f, 43f, 89f, 43f),
        floatArrayOf(70f, 50f, 82f, 50f, 82f, 56f, 92f, 56f, 95f, 56f),
        floatArrayOf(70f, 64f, 76f, 64f, 76f, 76f, 86f, 76f, 89f, 76f),
        floatArrayOf(64f, 70f, 64f, 84f, 64f, 87f),
        floatArrayOf(57f, 70f, 57f, 80f, 57f, 83f),
        floatArrayOf(50f, 70f, 50f, 92f, 50f, 95f),
        floatArrayOf(43f, 70f, 43f, 84f, 43f, 87f),
        floatArrayOf(36f, 70f, 36f, 76f, 27f, 76f, 27f, 86f, 27f, 89f),
        floatArrayOf(30f, 36f, 22f, 36f, 22f, 28f, 12f, 28f, 9f, 28f),
        floatArrayOf(30f, 43f, 16f, 43f, 13f, 43f),
        floatArrayOf(30f, 50f, 20f, 50f, 20f, 56f, 8f, 56f, 5f, 56f),
        floatArrayOf(30f, 64f, 24f, 64f, 24f, 74f, 14f, 74f, 11f, 74f),
    )

    override fun onDraw(canvas: Canvas) {
        canvas.save()
        canvas.scale(width / 100f, height / 100f)
        p.strokeJoin = Paint.Join.MITER
        for (t in traces) {
            val path = Path()
            path.moveTo(t[0], t[1])
            var i = 2
            while (i < t.size - 2) { path.lineTo(t[i], t[i + 1]); i += 2 }
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.2f; p.color = Color.parseColor("#1FBF4A")
            canvas.drawPath(path, p)
            p.strokeWidth = 2f; p.color = Color.parseColor("#39FF6A")
            canvas.drawCircle(t[t.size - 2], t[t.size - 1], 3.2f, p)
        }
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#1FBF4A"); canvas.drawRoundRect(RectF(30f, 30f, 70f, 70f), 2f, 2f, p)
        p.color = Color.parseColor("#C9FFD8"); canvas.drawRect(34f, 34f, 66f, 66f, p)
        p.color = Color.parseColor("#39FF6A"); canvas.drawRect(37f, 37f, 63f, 63f, p)
        p.color = Color.parseColor("#062712"); canvas.drawRect(41f, 41f, 59f, 59f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.parseColor("#8DFFAB")
        canvas.drawRect(41f, 41f, 59f, 59f, p)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textSize = 5.4f; p.textAlign = Paint.Align.CENTER
        canvas.drawText("h4xX", 50f, 48.5f, p)
        canvas.drawText("P4th", 50f, 55.5f, p)
        canvas.restore()
    }
}
