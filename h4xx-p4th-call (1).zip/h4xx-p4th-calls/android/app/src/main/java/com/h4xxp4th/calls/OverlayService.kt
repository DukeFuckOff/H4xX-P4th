package com.h4xxp4th.calls

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Only the pins are visible: docked at the right edge, not moving. Tap them to open a bubble
 * where you type a task. While a task runs the pins pulse (left pins appear too) and stop
 * blocking touches. STOP / EXIT are in the notification.
 */
class OverlayService : Service() {
    companion object {
        const val ACTION_RUN = "com.h4xxp4th.calls.RUN"
        const val ACTION_STOP = "com.h4xxp4th.calls.STOP"
        const val ACTION_QUIT = "com.h4xxp4th.calls.QUIT"
        private const val CHANNEL = "p4th"
        private const val MAX_STEPS = 25
    }

    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var dock: PinsView? = null
    private var dockLp: WindowManager.LayoutParams? = null
    private var leftPins: PinsView? = null
    private var bubble: LinearLayout? = null
    private var job: Job? = null
    private var controlling = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayLp(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundNotification()
        showDock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RUN -> intent.getStringExtra("goal")?.let { runAgent(it) }
            ACTION_STOP -> job?.cancel()
            ACTION_QUIT -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        dock?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        leftPins?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "H4xX p4th", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String) = PendingIntent.getService(this, a.hashCode(),
            Intent(this, OverlayService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("H4xX p4th active")
            .setContentText("STOP interrupts any running task")
            .addAction(Notification.Action.Builder(0, "STOP", pi(ACTION_STOP)).build())
            .addAction(Notification.Action.Builder(0, "EXIT", pi(ACTION_QUIT)).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- pins ----------
    private fun pinWindow(isLeft: Boolean, touchable: Boolean): Pair<PinsView, WindowManager.LayoutParams> {
        val v = PinsView(this, isLeft)
        val w = dp(28)
        val lp = overlayLp(w, dp(180), touchable).apply {
            gravity = (if (isLeft) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
        }
        wm.addView(v, lp)
        v.translationX = (if (isLeft) -w else w).toFloat()
        v.animate().translationX(0f).setDuration(300).start()
        return v to lp
    }

    private fun showDock() {
        if (dock != null) return
        val (v, lp) = pinWindow(false, true)
        v.setOnClickListener { toggleBubble() }
        dock = v
        dockLp = lp
    }

    private fun setControlling(on: Boolean) {
        controlling = on
        closeBubble()
        val d = dock
        val lp = dockLp
        if (d != null && lp != null) {
            d.active = on
            lp.flags = if (on) lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            else lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            try { wm.updateViewLayout(d, lp) } catch (_: Exception) {}
        }
        if (on) {
            if (leftPins == null) leftPins = pinWindow(true, false).first.also { it.active = true }
        } else {
            leftPins?.let { v ->
                v.animate().translationX(-dp(28).toFloat()).setDuration(250)
                    .withEndAction { try { wm.removeView(v) } catch (_: Exception) {} }.start()
            }
            leftPins = null
        }
    }

    // ---------- bubble to tell it what to do ----------
    private fun toggleBubble() { if (bubble != null) closeBubble() else openBubble() }

    private fun closeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    private fun openBubble() {
        if (controlling || bubble != null) return
        val green = Color.parseColor("#39FF6A")
        val width = minOf(resources.displayMetrics.widthPixels - dp(24), dp(330))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2020805"))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#6639FF6A"))
            }
        }
        box.addView(TextView(this).apply {
            text = "DukK5 h4xx : que hago, OPERATOR?"
            setTextColor(green); typeface = Typeface.MONOSPACE; textSize = 13f
        })
        val input = EditText(this).apply {
            hint = "escribe una tarea..."
            setTextColor(Color.parseColor("#C9FFD8"))
            setHintTextColor(Color.parseColor("#8839FF6A"))
            typeface = Typeface.MONOSPACE; textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            backgroundTintList = ColorStateList.valueOf(green)
            maxLines = 4
        }
        box.addView(input)
        box.addView(TextView(this).apply {
            text = "Para hablar usa el microfono del teclado."
            setTextColor(Color.parseColor("#9939FF6A")); typeface = Typeface.MONOSPACE; textSize = 11f
        })
        fun send() {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { closeBubble(); runAgent(t) }
        }
        input.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEND) { send(); true } else false
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text = "RUN"; setOnClickListener { send() } })
        row.addView(Button(this).apply { text = "CLOSE"; setOnClickListener { closeBubble() } })
        box.addView(row)
        box.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closeBubble(); true } else false
        }
        val lp = WindowManager.LayoutParams(width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12); y = dp(90)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(box, lp)
        bubble = box
        input.requestFocus()
        input.post {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    // ---------- confirmation for consequential actions ----------
    private suspend fun confirm(reason: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            setBackgroundColor(Color.parseColor("#F0020805"))
        }
        box.addView(TextView(this).apply {
            text = "DukK5 h4xx : CONFIRM\n$reason"
            setTextColor(Color.parseColor("#39FF6A")); typeface = Typeface.MONOSPACE; textSize = 14f
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text = "ALLOW"; setOnClickListener { d.complete(true) } })
        row.addView(Button(this).apply { text = "DENY"; setOnClickListener { d.complete(false) } })
        box.addView(row)
        val lp = overlayLp(dp(300), WindowManager.LayoutParams.WRAP_CONTENT, true).apply { gravity = Gravity.CENTER }
        wm.addView(box, lp)
        try { return d.await() } finally { try { wm.removeView(box) } catch (_: Exception) {} }
    }

    // ---------- agent loop ----------
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun runAgent(goal: String) {
        if (job?.isActive == true) { toast("A task is already running."); return }
        val ctl = ControlService.instance
        if (ctl == null) { toast("DukK5 h4xx : ERROR accessibility service not enabled."); return }
        if (Session.server.isBlank() || Session.key.isBlank()) { toast("DukK5 h4xx : ERROR server or key missing. Open the app once."); return }
        job = scope.launch {
            setControlling(true)
            var result = "Done."
            try {
                val history = JSONArray()
                for (step in 1..MAX_STEPS) {
                    val screen = ctl.snapshot()
                    val r = withContext(Dispatchers.IO) {
                        Api.http("POST", "${Session.server}/agent/step", Session.key,
                            JSONObject().put("goal", goal).put("screen", screen).put("history", history))
                    }
                    val act = r.optJSONObject("action")
                    if (r.optBoolean("done") || act == null) { result = r.optString("say").ifBlank { "Done." }; break }
                    if (r.optBoolean("needs_confirm") && !confirm(r.optString("reason").ifBlank { act.toString() })) {
                        result = "Cancelled by operator."; break
                    }
                    val ok = ctl.perform(act)
                    history.put("${act.optString("type")} ${act.optString("text", act.optString("name", ""))} " +
                        if (ok) "ok" else "FAILED")
                    delay(1300)
                    if (step == MAX_STEPS) result = "Step limit reached."
                }
            } catch (e: CancellationException) {
                result = "Stopped by operator."
                throw e
            } catch (e: Exception) {
                result = "ERROR ${e.message}"
            } finally {
                setControlling(false)
                toast("DukK5 h4xx : $result")
            }
        }
    }
}
