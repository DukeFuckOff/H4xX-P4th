package com.h4xxp4th.calls

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * Floating mascot. While an agent task runs, the mascot disappears and only the side pins stay visible.
 * STOP / EXIT are in the notification. Consequential actions need an on-screen ALLOW.
 */
class OverlayService : Service() {
    companion object {
        const val ACTION_RUN = "com.h4xxp4th.calls.RUN"
        const val ACTION_STOP = "com.h4xxp4th.calls.STOP"
        const val ACTION_QUIT = "com.h4xxp4th.calls.QUIT"
        private const val CHANNEL = "p4th"
        private const val MAX_STEPS = 25
    }

    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var mascot: MascotView? = null
    private var mascotLp: WindowManager.LayoutParams? = null
    private var left: PinsView? = null
    private var right: PinsView? = null
    private var job: Job? = null
    private var dragging = false
    private var controlling = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayLp(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundNotification()
        showMascot()
        handler.postDelayed(wander, 5000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RUN -> intent.getStringExtra("goal")?.let { runAgent(it) }
            ACTION_STOP -> job?.cancel()
            ACTION_QUIT -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        handler.removeCallbacksAndMessages(null)
        mascot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        left?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        right?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "H4xX p4th", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String) = PendingIntent.getService(this, a.hashCode(),
            Intent(this, OverlayService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("H4xX p4th active")
            .setContentText("STOP interrupts any running task")
            .addAction(Notification.Action.Builder(0, "STOP", pi(ACTION_STOP)).build())
            .addAction(Notification.Action.Builder(0, "EXIT", pi(ACTION_QUIT)).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- mascot ----------
    private fun showMascot() {
        if (mascot != null) return
        val v = MascotView(this)
        val lp = mascotLp ?: overlayLp(dp(96), dp(96), true).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(40); y = dp(220)
        }
        mascotLp = lp
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; dragging = true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moved = true
                    if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> {
                    dragging = false
                    if (!moved) startActivity(Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                }
                MotionEvent.ACTION_CANCEL -> dragging = false
            }
            true
        }
        wm.addView(v, lp)
        mascot = v
        v.alpha = 0f; v.scaleX = .3f; v.scaleY = .3f
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(250).start()
    }

    private fun hideMascot() {
        val v = mascot ?: return
        mascot = null
        v.animate().alpha(0f).scaleX(.3f).scaleY(.3f).setDuration(220)
            .withEndAction { try { wm.removeView(v) } catch (_: Exception) {} }.start()
    }

    private val wander = object : Runnable {
        override fun run() {
            val v = mascot; val lp = mascotLp
            if (v != null && lp != null && !dragging && !controlling) {
                val dm = resources.displayMetrics
                val tx = ((dm.widthPixels - dp(96)) * Math.random()).toInt()
                val ty = (dp(80) + (dm.heightPixels - dp(300)) * Math.random()).toInt()
                val sx = lp.x; val sy = lp.y
                ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 3200
                    addUpdateListener { a ->
                        if (mascot === v && !dragging) {
                            val f = a.animatedFraction
                            lp.x = (sx + (tx - sx) * f).toInt(); lp.y = (sy + (ty - sy) * f).toInt()
                            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                        }
                    }
                }.start()
            }
            handler.postDelayed(this, 7000)
        }
    }

    // ---------- side pins ----------
    private fun pinWindow(isLeft: Boolean): PinsView {
        val v = PinsView(this, isLeft)
        val w = dp(36)
        val lp = overlayLp(w, dp(5 * 44), false).apply {
            gravity = (if (isLeft) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
        }
        wm.addView(v, lp)
        v.translationX = (if (isLeft) -w else w).toFloat()
        v.animate().translationX(0f).setDuration(300).start()
        return v
    }

    private fun showPins() {
        if (left == null) left = pinWindow(true)
        if (right == null) right = pinWindow(false)
    }

    private fun hidePins() {
        listOf(left, right).forEach { v ->
            if (v != null) {
                val d = if (v.isLeft) -dp(36) else dp(36)
                v.animate().translationX(d.toFloat()).setDuration(250)
                    .withEndAction { try { wm.removeView(v) } catch (_: Exception) {} }.start()
            }
        }
        left = null; right = null
    }

    private fun setControlling(on: Boolean) {
        controlling = on
        if (on) { hideMascot(); showPins() } else { hidePins(); showMascot() }
    }

    // ---------- confirmation for consequential actions ----------
    private suspend fun confirm(reason: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            setBackgroundColor(Color.parseColor("#F0020805"))
        }
        box.addView(TextView(this).apply {
            text = "DukK5 h4xx : CONFIRM\n$reason"
            setTextColor(Color.parseColor("#39FF6A")); typeface = Typeface.MONOSPACE; textSize = 14f
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text = "ALLOW"; setOnClickListener { d.complete(true) } })
        row.addView(Button(this).apply { text = "DENY"; setOnClickListener { d.complete(false) } })
        box.addView(row)
        val lp = overlayLp(dp(300), WindowManager.LayoutParams.WRAP_CONTENT, true).apply { gravity = Gravity.CENTER }
        wm.addView(box, lp)
        try { return d.await() } finally { try { wm.removeView(box) } catch (_: Exception) {} }
    }

    // ---------- agent loop ----------
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun runAgent(goal: String) {
        if (job?.isActive == true) { toast("A task is already running."); return }
        val ctl = ControlService.instance
        if (ctl == null) { toast("DukK5 h4xx : ERROR accessibility service not enabled."); return }
        if (Session.server.isBlank() || Session.key.isBlank()) { toast("DukK5 h4xx : ERROR server or key missing."); return }
        job = scope.launch {
            setControlling(true)
            var result = "Done."
            try {
                val history = JSONArray()
                for (step in 1..MAX_STEPS) {
                    val screen = ctl.snapshot()
                    val r = withContext(Dispatchers.IO) {
                        Api.http("POST", "${Session.server}/agent/step", Session.key,
                            JSONObject().put("goal", goal).put("screen", screen).put("history", history))
                    }
                    val act = r.optJSONObject("action")
                    if (r.optBoolean("done") || act == null) { result = r.optString("say").ifBlank { "Done." }; break }
                    if (r.optBoolean("needs_confirm") && !confirm(r.optString("reason").ifBlank { act.toString() })) {
                        result = "Cancelled by operator."; break
                    }
                    val ok = ctl.perform(act)
                    history.put("${act.optString("type")} ${act.optString("text", act.optString("name", ""))} " +
                        if (ok) "ok" else "FAILED")
                    delay(1300)
                    if (step == MAX_STEPS) result = "Step limit reached."
                }
            } catch (e: CancellationException) {
                result = "Stopped by operator."
                throw e
            } catch (e: Exception) {
                result = "ERROR ${e.message}"
            } finally {
                setControlling(false)
                toast("DukK5 h4xx : $result")
            }
        }
    }
}
