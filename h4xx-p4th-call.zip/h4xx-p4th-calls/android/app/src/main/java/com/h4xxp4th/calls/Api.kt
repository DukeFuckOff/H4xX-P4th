package com.h4xxp4th.calls

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** In-memory only. Lives as long as the app process (the foreground service keeps it alive). */
object Session {
    @Volatile var server = ""
    @Volatile var key = ""
}

object Api {
    fun http(method: String, url: String, key: String, body: JSONObject? = null): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 10000
        c.readTimeout = 30000
        c.setRequestProperty("X-App-Key", key)
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code >= 400) throw IOException("HTTP $code: $text")
        return JSONObject(text)
    }
}
