package com.h4xxp4th.calls

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

private val Green = Color(0xFF39FF6A)
private val E164 = Regex("^\\+[1-9]\\d{6,14}$")
private val DONE = setOf("completed", "failed", "busy", "no-answer", "canceled")

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)

    override fun onResume() { super.onResume(); tick.intValue++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Green, onPrimary = Color.Black,
                    background = Color(0xFF020805), onBackground = Color(0xFFC9FFD8),
                    surface = Color(0xFF04140A), onSurface = Color(0xFFC9FFD8),
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Screen(tick.intValue) }
            }
        }
    }
}

@Composable
private fun Screen(tick: Int) {
    val ctx = LocalContext.current
    val prefs = ctx.getSharedPreferences("p4th", 0)
    var server by remember { mutableStateOf(prefs.getString("server", "") ?: "") }
    var key by remember { mutableStateOf(Session.key) }
    var agentGoal by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var callGoal by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("DukK5 h4xx : READY, OPERATOR.") }
    var cid by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val base = server.trim().trimEnd('/')
    val mono = FontFamily.Monospace
    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val a11yOk = remember(tick) { ControlService.instance != null }
    val serverOk = base.startsWith("https://") && key.isNotBlank()

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { agentGoal = it }
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
    }

    fun sync() { Session.server = base; Session.key = key; prefs.edit().putString("server", server.trim()).apply() }

    fun startCall() {
        scope.launch {
            busy = true
            try {
                sync()
                val r = withContext(Dispatchers.IO) {
                    Api.http("POST", "$base/call", key,
                        JSONObject().put("to", number.trim()).put("goal", callGoal.trim()))
                }
                cid = r.getString("cid")
                out = "DukK5 h4xx : CALL REQUESTED. Tracking status."
                while (true) {
                    delay(3000)
                    val s = withContext(Dispatchers.IO) { Api.http("GET", "$base/calls/$cid", key) }
                    val st = s.getString("status")
                    val tr = s.getJSONArray("transcript")
                    val sb = StringBuilder("STATUS: $st\n\n")
                    for (i in 0 until tr.length()) {
                        val t = tr.getJSONObject(i)
                        sb.append(if (t.getString("who") == "ai") "AI: " else "CALLEE: ").append(t.getString("text")).append("\n")
                    }
                    out = sb.toString()
                    if (st in DONE) break
                }
            } catch (e: Exception) {
                out = "DukK5 h4xx : ERROR ${e.message}"
            }
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("H4xX p4th", color = Green, fontFamily = mono, style = MaterialTheme.typography.titleLarge)
        Text("overlay permission: ${if (overlayOk) "OK" else "MISSING"}\naccessibility service: ${if (a11yOk) "ON" else "OFF"}",
            fontFamily = mono, color = MaterialTheme.colorScheme.onBackground)

        OutlinedTextField(server, { server = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Server URL (https)") })
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("App key") }, visualTransformation = PasswordVisualTransformation())

        Text("SETUP", color = Green, fontFamily = mono)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }) { Text("OVERLAY") }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }) { Text("ACCESSIBILITY") }
        }
        Button(onClick = {
            sync()
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            else ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
        }, enabled = overlayOk) { Text("START") }

        Text("AGENT (controls the screen)", color = Green, fontFamily = mono)
        OutlinedTextField(agentGoal, { agentGoal = it }, Modifier.fillMaxWidth(), minLines = 2,
            label = { Text("Task, e.g. open Settings and turn on dark mode") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                try {
                    speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
                } catch (e: ActivityNotFoundException) { out = "DukK5 h4xx : ERROR no speech recognizer on this device." }
            }) { Text("VOICE") }
            Button(onClick = {
                sync()
                ctx.startForegroundService(Intent(ctx, OverlayService::class.java)
                    .setAction(OverlayService.ACTION_RUN).putExtra("goal", agentGoal.trim()))
                (ctx as? ComponentActivity)?.moveTaskToBack(true)
            }, enabled = overlayOk && a11yOk && serverOk && agentGoal.isNotBlank()) { Text("RUN") }
        }

        Text("CALL (via Twilio server)", color = Green, fontFamily = mono)
        OutlinedTextField(number, { number = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Number, e.g. +34600111222") })
        OutlinedTextField(callGoal, { callGoal = it }, Modifier.fillMaxWidth(), minLines = 2,
            label = { Text("Goal of the call") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { confirm = true },
                enabled = serverOk && E164.matches(number.trim()) && callGoal.isNotBlank() && !busy) { Text("CALL") }
            OutlinedButton(onClick = {
                scope.launch {
                    try { withContext(Dispatchers.IO) { Api.http("POST", "$base/calls/$cid/hangup", key) } }
                    catch (e: Exception) { out = "DukK5 h4xx : ERROR ${e.message}" }
                }
            }, enabled = busy && cid != null) { Text("HANG UP") }
        }
        Text(out, fontFamily = mono, color = MaterialTheme.colorScheme.onBackground)
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Confirm real call") },
            text = { Text("A real call will be placed to ${number.trim()} from your Twilio number. The AI will announce that it is an AI. Only call numbers you are allowed to call.") },
            confirmButton = { TextButton(onClick = { confirm = false; startCall() }) { Text("CALL") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("CANCEL") } }
        )
    }
}
