package com.h4xxp4th.calls

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

/** Reads the screen and performs taps / swipes / typing. The user must enable it in Accessibility settings. */
class ControlService : AccessibilityService() {
    companion object {
        @Volatile var instance: ControlService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Visible UI elements as JSON. Password fields never expose their content. */
    fun snapshot(): JSONArray {
        val out = JSONArray()
        val root = rootInActiveWindow ?: return out
        out.put(JSONObject().put("pkg", root.packageName?.toString() ?: ""))
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (out.length() >= 120 || depth > 25) return
            if (n.isVisibleToUser) {
                val pw = n.isPassword
                val t = if (pw) "" else (n.text?.toString() ?: "")
                val d = n.contentDescription?.toString() ?: ""
                if (t.isNotBlank() || d.isNotBlank() || n.isClickable || n.isEditable) {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    out.put(JSONObject().put("t", t.take(80)).put("d", d.take(80))
                        .put("c", n.isClickable).put("e", n.isEditable).put("p", pw)
                        .put("x", r.centerX()).put("y", r.centerY()))
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(root, 0)
        return out
    }

    suspend fun perform(a: JSONObject): Boolean = when (a.optString("type")) {
        "open_app" -> openApp(a.optString("name"))
        "tap_text" -> tapText(a.optString("text"))
        "tap" -> tap(a.optInt("x").toFloat(), a.optInt("y").toFloat())
        "type" -> typeText(a.optString("text"))
        "swipe" -> swipe(a.optString("dir"))
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "wait" -> true
        else -> false
    }

    private fun openApp(name: String): Boolean {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    private fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            if (n.isPassword) continue
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable && !n.isPassword) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findEditable(c)?.let { return it }
        }
        return null
    }

    private fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        if (n.isPassword) return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private suspend fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        return gesture(path, 60)
    }

    private suspend fun swipe(dir: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val (x1, y1, x2, y2) = when (dir) {
            "up" -> listOf(w / 2, h * .7f, w / 2, h * .3f)
            "down" -> listOf(w / 2, h * .3f, w / 2, h * .7f)
            "left" -> listOf(w * .8f, h / 2, w * .2f, h / 2)
            "right" -> listOf(w * .2f, h / 2, w * .8f, h / 2)
            else -> return false
        }
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return gesture(path, 350)
    }

    private suspend fun gesture(path: Path, duration: Long): Boolean = suspendCancellableCoroutine { c ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (c.isActive) c.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (c.isActive) c.resume(false) }
        }, null)
        if (!ok && c.isActive) c.resume(false)
    }
}
