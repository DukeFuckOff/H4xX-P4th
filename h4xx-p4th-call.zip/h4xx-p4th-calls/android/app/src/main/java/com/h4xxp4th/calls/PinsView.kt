package com.h4xxp4th.calls

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/** Five glowing chip pins sticking out from one screen edge. Shown while the agent controls the phone. */
class PinsView(context: Context, val isLeft: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 1400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val n = 5
        val gap = height / n.toFloat()
        val th = gap * 0.42f
        val len = width * 0.88f
        for (i in 0 until n) {
            val cy = gap * (i + 0.5f)
            val a = (0.6f + 0.4f * sin(phase - i * 0.9f)).coerceIn(0f, 1f)
            val r = if (isLeft) RectF(0f, cy - th / 2, len, cy + th / 2)
            else RectF(width - len, cy - th / 2, width.toFloat(), cy + th / 2)
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#D7FFE3")
            p.alpha = (255 * a).toInt()
            p.setShadowLayer(10f, 0f, 0f, Color.parseColor("#39FF6A"))
            canvas.drawRoundRect(r, th / 2, th / 2, p)
        }
    }
}
