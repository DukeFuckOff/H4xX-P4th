# H4xX p4th Calls (prototype)

STATUS: generated code. NOT compiled, NOT run, NOT tested against Twilio.

Flow: Android app -> your server (/call) -> Twilio dials the number -> Twilio ConversationRelay
streams the callee's speech as text to /ws -> Claude writes the reply -> Twilio speaks it.
The AI announces it is an AI in a fixed greeting set by the server (the model cannot remove it).

## What you need
- Twilio account + a voice-capable phone number (trial accounts can only call verified numbers).
- Check Twilio's current ConversationRelay docs for availability and message format; if they changed, adjust /ws in server/main.py.
- Anthropic API key.
- A public https URL for the server (ngrok, cloudflared tunnel, or any host).
- Python 3.10+, Android Studio.

## Server
cd server
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill every value
uvicorn main:app --host 0.0.0.0 --port 8000
# in another terminal: ngrok http 8000  -> put the https URL in PUBLIC_URL, restart the server

## Get the APK (no Android Studio needed)
1. Create a GitHub repo and upload the contents of this folder (keep the `.github` folder).
2. Repo > Actions > "Build APK" > Run workflow. When it finishes, download the artifact `h4xx-p4th-apk`.
3. Unzip, copy `app-debug.apk` to the phone, install it (allow "install unknown apps").
Or open the `android/` folder in Android Studio and use Build > Build APK.
STATUS: the workflow and the Kotlin code have NOT been run. If the build fails, send me the error log.

## First run on the phone
1. Open the app, enter the server URL (https) and the app key.
2. OVERLAY: allow "display over other apps".
3. ACCESSIBILITY: enable "H4xX p4th Control". If Android blocks it ("restricted setting"), go to
   Settings > Apps > H4xX p4th > three dots > "Allow restricted settings", then try again.
4. START MASCOT: the chip appears, roams the screen, can be dragged; tap it to reopen the app.
5. Type or speak (VOICE) a task and press RUN.

## How the agent behaves
- While a task runs the mascot disappears and only the pins on the left and right screen edges stay visible.
- It reads the visible screen, asks the server (Claude) for ONE action, performs it, repeats (max 25 steps).
- STOP and EXIT are in the notification. The pins do not block touches.
- Consequential actions (purchases, sending messages, deleting, installing, security settings, calls)
  show an ALLOW / DENY box first.
- It never types into password fields, and the model is told not to bypass logins or lock screens.
- Some apps (banking, some video apps) block accessibility reading. Expect failures there.
- Screen content is sent to your server and Claude. Do not run tasks on screens with private data you do not want shared.

## Safety built in
- Fixed AI disclosure greeting; model told never to claim to be human.
- App confirmation dialog before every call, STOP button (hangs up via Twilio).
- X-App-Key auth, Twilio signature check on webhooks, hourly call cap, max call length,
  optional ALLOWED_NUMBERS allowlist, no call recording.
- Model refuses payments, passwords, card numbers, personal data.

## Your responsibility
Calling people with an AI voice is regulated (for example, US rules treat AI voices as
artificial voices and require consent for many calls). Only call numbers you are allowed to
call, such as businesses for a normal errand or people who agreed. Check your local law.

## Known gaps
- Sessions live in memory (restart = lost). Single instance only.
- If the goodbye gets cut off when the call ends, add a short delay before the "end" message.
- This does not talk inside your normal phone calls. It makes its own calls through Twilio.
- Prototype quality: untested on a real device, steps limited to 25, one task at a time.
